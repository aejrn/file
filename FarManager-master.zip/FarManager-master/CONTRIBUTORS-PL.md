|[English](CONTRIBUTORS.md)|
|-|

# Grupa Far - historia i teraźniejszość
* Valentin Skirdin
* Ivan Sintyurin
* Konstantin Stupnik
* Ilya V. Gershman
* Dmitry Shtivel
* Oleg L. Taranenko
* Konstantin Melnikov
* Andrey Tretyakov
* Vasily V. Moshninov
* Dmitry Jemerov
* WARP ItSelf
* Alex Yaroslavsky
* Eugene Leskinen
* Alexey Kuznetsov
* Vadim Yegorov
* Iouri Kharon
* Yuris W. Auzinsh
* Tim Sobolev
* Sergey Dindikov
* Alex Alabuzhev
* Igor A. Vyatkin
* lort
* Oleg Makovski
* Vladimir Surguchev
* Shmuel Zeigerman

# Społeczność współtworząca Far i wtyczki
*Jeżeli uważasz, że brakuje Cię na tej liście - daj nam znać.*

* Alexey Semenov
* Roman Pekhov
* Alexander Arefiev
* Dennis Trachuk
* Sergei Antonov
* Alexander Kornienko
* Alexander Nazarenko
* Jouri Mamaev
* Michael Yutsis
* Andrey Novosilov
* Wesha the Leopard
* George Hazan
* Igor Paikin
* Andrey Budko
* Alexey Yatsenko
* Igor Ruskih
* Max Belugin
* Artyom Nazarov
* Kirill Kirichenko
* Eugene Mindrov
* Roman Vorobets
* Alexander Nesterovsky
* Peter Koves
* Oliver Schneider
* Max Gorobchuk
* Pawel Pawlak
* Andrey Tsybin
* Roman Synyshyn
* Alexey Samlyukov
* Anton Tagunov
* Alexandr Zamaraev
* Max Shirshin
* Alexander Mitin
* Stanislav Vinokurov
* Hannes Eder
* Sergiy Voloshyn
* George Yohng
* Dmitry Ovdienko
* Andrey Kuznetsov
* Denis Kosy
* Dmitry Ponomarev
* Vitaliy Didik
* Morten MacFly
* Igor O. Bochkariov
* Max Moysyuk
* Alexey Pakhunov
* Roman Kuzmin
* techtonik
* Radek Kubicek
* Thomas Wolf
* Far Hunor
* Andrey Starodubtsev
* Maciej Ogrodniczuk
* dialex
* Igor Babichev
* Kostia Romanov
* Igor Yudincev
* Evgeny Zhirnov
* Maxim Rusov
* vitbo
* Igor Braginskiy
* Oleg Hiderman
* pepak
* Anton Sinitsin
* Dmitry Atamanov
* Yegor Myalik
* Sergey Karpukhin
* Mike Mirzayanov
* Martin Xarx
* Ivan Vanyushkin
* Victor Istomin
* Vlad Lozynskyi
* Kate Fedorova
* Mauro72
* dimfish
* Dmitri Davydok
* Pavol Misik
* Timofey Vasenin
* Michael Z. Kadaner
* Vladimir Fekete
* Daniele Babolin
* Jesko Huettenhain
* Andrzej Rudnik
* Dzmitry Kosko
* Szabolcs Szász
* HamRusTal
* Michal Zobec
* Gerardo Garcia
* Bernd Giesen
* Juri Petrashko
* Valentіn Kolesnіkov
* Вя Лi
* Michal Breškovec
* Miroslav Pták
* Peter Valach
* Paweł Pawlak
* XSAk
* Arūnas Bartišius
* Rohitab Batra
 
> I specjalne podziękowania dla wszystkich członków naszej społeczności!<br/>
> Jesteście nie mniej ważni niż osoby tutaj wymienione.
