Files here are used to build the following manuals:

* Far API reference - https://api.farmanager.com, https://fargroup.github.io/api
* Far API reference in .CHM format
* Lua API reference in .CHM format
